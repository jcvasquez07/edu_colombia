<li class="nav-item has-treeview">
    <a href="#" class="nav-link bg-info navbar-light">
        <i class="nav-icon fas fa-file-signature"></i>
        <p>Examen<i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-edit nav-icon"></i>
                <p>Programa de exámenes</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-award nav-icon"></i>
                <p>Grado</p>
            </a>
        </li>

        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fas fa-cubes"></i>&nbsp;&nbsp;
                <p>Asistencia al examen</p>
            </a>
        </li>                   

    </ul>
</li>