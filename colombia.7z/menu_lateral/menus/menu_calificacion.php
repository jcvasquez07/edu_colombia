<li class="nav-item has-treeview">
    <a href="#" class="nav-link bg-success navbar-light">
        <i class="nav-icon fas fa-clipboard-check"></i>
        <p>Calificación<i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-spell-check nav-icon"></i>
                <p>Calificar Examen</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-check-double nav-icon"></i>
                <p>Calificar Tareas</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-list-ol nav-icon"></i>
                <p>Distribución de calificación</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-graduation-cap nav-icon"></i>
                <p>Promoción</p>
            </a>
        </li>                    
    </ul>
</li>