<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon fas fa-file-alt"></i>
        <p>Informes<i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-paste nav-icon"></i>
                <p>Diplomas</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-paste nav-icon"></i>
                <p>Constancias</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-paste nav-icon"></i>
                <p>Etapa de merito</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-paste nav-icon"></i>
                <p>Hoja de tabulación</p>
            </a>
        </li>

        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-paste nav-icon"></i>
                <p>Hoja de Calificacion</p>
            </a>
        </li>

        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-paste nav-icon"></i>
                <p>Tarjeta de progreso</p>
            </a>
        </li>

        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-paste nav-icon"></i>
                <p>Examen Online</p>
            </a>
        </li>

        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-paste nav-icon"></i>
                <p>Paz y salvo</p>
            </a>
        </li>

        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-paste nav-icon"></i>
                <p>Tarifas</p>
            </a>
        </li>

        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-paste nav-icon"></i>
                <p>Deudas</p>
            </a>
        </li>

        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-paste nav-icon"></i>
                <p>Multa estudiantil</p>
            </a>
        </li>

    </ul>
</li>