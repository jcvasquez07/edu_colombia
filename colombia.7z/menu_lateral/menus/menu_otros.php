<li class="nav-item has-treeview">
    <a href="#" class="nav-link bg-light navbar-light">
        <i class="nav-icon fas fa-book"></i>
        <p>Otros<i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fas fa-envelope"></i>&nbsp;&nbsp;
                <p>Mensajes</p>
                <span class="right badge badge-warning">Nuevo</span>
            </a>
        </li><li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fas fa-film"></i>&nbsp;&nbsp;
                <p>Modulos</p>
            </a>
        </li>

        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fas fa-pencil-ruler"></i>&nbsp;&nbsp;
                <p>Examen Online</p>
            </a>
        </li>                              
    </ul>
</li>