<li class="nav-item has-treeview">
    <a href="#" class="nav-link bg-light navbar-light">
        <i class="fa fa-dollar-sign nav-icon" style="color:#000000;"></i>                   
        <p>Tarifas<i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="#" class="nav-link">                        
                <i class="fa fa-check-circle nav-icon" style="color:#009900;"></i>
                <p>Tipo de tarifa</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-check-circle nav-icon" style="color:#009900;"></i>
                <p>Asignar tarifa por Alumno</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-check-circle nav-icon" style="color:#009900;"></i>
                <p>Asignar tarifa por Grupo</p>
            </a>
        </li>                               
    </ul>
</li>