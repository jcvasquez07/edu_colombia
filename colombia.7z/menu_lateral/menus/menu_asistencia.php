<li class="nav-item has-treeview">
    <a href="#" class="nav-link bg-secondary navbar-dark">
        <i class="nav-icon fas fa-clipboard-list"></i>
        <p>Asistencia<i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-user-check nav-icon"></i>
                <p>Asistencia de Estudiantes</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-address-card nav-icon"></i>
                <p>Asistencia de Docente</p>
            </a>
        </li>

        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fas fa-id-card-alt"></i>&nbsp;&nbsp;
                <p>Asistencia de Personal</p>
            </a>
        </li>                   

    </ul>
</li>