<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon fas fa-user-secret"></i>
        <p>Administrador<i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-money-bill-alt nav-icon"></i>
                <p>Metodo de Pago</p>
            </a>
        </li>

        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-user-tie nav-icon"></i>
                <p>Habilitar usuarios</p>
            </a>
        </li>                              
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-unlock-alt nav-icon"></i>
                <p>Restablecer Contraseña</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-thumbs-up nav-icon"></i>
                <p>Redes sociales</p>
            </a>
        </li> 
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-envelope-open-text nav-icon"></i>
                <p>Plantilla de correo</p>
            </a>
        </li>   
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-crown nav-icon"></i>
                <p>Administrador del Sistema</p>
            </a>
        </li>  
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-list-ol nav-icon"></i>
                <p>Rol</p>
            </a>
        </li>      
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-users-cog nav-icon"></i>
                <p>Permiso</p>
            </a>
        </li>    
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-server nav-icon"></i>
                <p>Copia de seguridad</p>
            </a>
        </li> 

        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-cogs nav-icon"></i>
                <p>Configuración General</p>
            </a>
        </li>                                         
    </ul>
</li>