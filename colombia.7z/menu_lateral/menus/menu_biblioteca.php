<li class="nav-item has-treeview">
    <a href="#" class="nav-link bg-light navbar-light">
        <i class="nav-icon fas fa-book"></i>
        <p>Biblioteca<i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-atlas nav-icon"></i>
                <p>Libros Fisicos</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-file-invoice nav-icon"></i>
                <p>E-books</p>
            </a>
        </li>                               
    </ul>
</li>