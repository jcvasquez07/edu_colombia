<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon fas fa-tools"></i>
        <p>Configuración<i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-cog nav-icon"></i>
                <p>Año académico</p>
            </a>
        </li>                   
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-cog nav-icon"></i>
                <p>De correo electrónico</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="fa fa-cog nav-icon"></i>
                <p>De mensajes de texto</p>
            </a>
        </li>                                  
    </ul>
</li>