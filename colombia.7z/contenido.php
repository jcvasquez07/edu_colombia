<?php

switch ($pagina) {
    case 'dashboard':
        include "dashboard/dashboard.php";
        break;
    default:
        include "dashboard/dashboard.php";
        break;
}

